
#ifndef __kofn_hh__
#define __kofn_hh__

void kOfN (int k, int n, int* values);

#endif // __kofn_hh__
