function [G, L, fil] = pyramidsGL(im, N)
% [G, L] = pyramidsGL(im, N)
% Creates Gaussian (G) and Laplacian (L) pyramids of level N from image im.
% fil is the smoothing filter that is used

% if size(im, 3)==3
%   im = rgb2gray(im);
% end

G = cell(N, 1);
L = cell(N, 1);
fil = fspecial('gaussian', 13, 2);
G{1} = im;
for n = 1:N-1
  im_sm = imfilter(G{n}, fil);
  G{n+1} = im_sm(1:2:end, 1:2:end, :);
  L{n} = G{n}-imfilter(imresize(G{n+1}, [size(G{n},1) size(G{n},2)], 'nearest'), fil);  
end
L{N} = G{N};


