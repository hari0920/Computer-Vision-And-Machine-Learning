function displayPyramids(G, L)
% Displays intensity and fft images of pyramids

N = numel(G);
close all;

sz = size(G{1});

figure(1), hold off; clf
sp = tight_subplot(2,N,[.01 .03],[.1 .01],[.01 .01]); % to reduce space between images compared to subplot
for n = 1:N
  axes(sp(n));  imagesc(G{n}), axis off, axis image; colormap gray; %, sz, 'nearest'));
  axes(sp(n+N)); imagesc(L{n}), axis off, axis image; colormap gray; %show(imresize(mat2gray(L{n}), sz, 'nearest'));
end

figure(2), hold off; clf;
sp = tight_subplot(2,N,[.01 .03],[.1 .01],[.01 .01]); 
for n = 1:N
  axes(sp(n)), displayFFT(G{n}, 0, 10);
  axes(sp(n+N)), displayFFT(L{n}, 0, 10);
end


function displayFFT(im, minv, maxv)
fftim = fft2(im);
fftim = fftshift(fftim);
fftimpow = log(abs(fftim+eps));
imagesc(fftimpow, [minv maxv]), axis off, colormap jet, axis image

% function tight
% ha = tight_subplot(3,2,[.01 .03],[.1 .01],[.01 .01]) 
% for ii = 1:6; axes(ha(ii)); plot(randn(10,ii)); end 
% set(ha(1:4),'XTickLabel',''); set(ha,'YTickLabel','')
