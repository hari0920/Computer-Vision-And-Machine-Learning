function find_annotator()
  load annotation_data  
%   load my
  I = unique(image_ids)'; A = unique(annotator_ids)';
  N = numel(image_ids);
  beta1 = .5;
  sigma = std(annotation_scores);
  mu = zeros(numel(I), 1);
  for i=1:numel(I)
    mu( I(i) ) = mean( annotation_scores(image_ids==I(i)) );
  end
  
  old_z = zeros(numel(A), 1);
  while 1
%     old_z'
%     keyboard;
    % e step
    l = zeros(numel(I), 2);
    for k=1:N
      l(k,1)=normpdf(annotation_scores(k), mu(image_ids(k)), sigma);
    end
    l(:, 1) = log(l(:, 1));
    l(:, 2) = log(1/10);
    
    z = zeros(numel(A), 1);
    for a=1:numel(A)
      idx = annotator_ids==A(a);
      t1 = log(beta1) + sum(l(idx,1));
      t2 = log(1-beta1) + sum(l(idx,2));
      z(a) = exp(t1)/(exp(t1)+exp(t2));
    end
    % m step
    
    zi1 = z(annotator_ids);
    beta1 = sum(zi1)/ N;

    for i=1:numel(I)
      idx = image_ids==I(i);
      mu(i) = sum(annotation_scores(idx).*zi1(idx)) / sum(zi1(idx));
    end
    sigma = sqrt(sum((annotation_scores - mu(image_ids)).^2 .* zi1) / sum(zi1));
    
    if sum(abs(z-old_z))<1e-2
      break;
    end
    old_z = z;
  end
  good = (z>.5);
  fprintf('Indices of bad annotators: ');
  fprintf('%d ', find(~good));
  fprintf('\n');
  fprintf('Sigma = %f\n', sigma);
  for i=1:numel(I)
    mean_scores(i) = mean( annotation_scores( good(annotator_ids) & image_ids==i ) );
  end
  plot(1:150, mu(1:150));
  keyboard;
end