addpath(genpath('GCmex1.5'));
im = im2double( imread('cat.jpg') );
org_im = im;
H = size(im, 1); W = size(im, 2); K = 3;
load cat_poly
inbox = poly2mask(poly(:,1), poly(:,2), size(im, 1), size(im,2));
%inbox(104:248, 29:475) = 1;
% pos = bwdist(inbox);
% pos = pos - bwdist(~inbox);
% im = cat(3, im, pos/W);

% im = cat(3, im, meshX, meshY);

c = {};
for k=1:K
  t=im(:,:,k); c{k} = t(logical(inbox));
end
c = cell2mat(c);
in_dist = gmdistribution.fit(c, 4);
p_in = pdf(in_dist, reshape(im, [H*W K]) );
p_in = reshape(p_in, [H W] );
%p_in = ones(size(p_in)) * log(.55);

c = {};
for k=1:K
  t=im(:,:,k); c{k} = t(~logical(inbox));
end
c = cell2mat(c);
out_dist = gmdistribution.fit(c, 4);
p_out = pdf(out_dist, reshape(im, [H*W K]) );
p_out = reshape(p_out, [H W] );

%%
gx = {}; gy = {};
sigma = .01;
for k=1:K
  [gx{k}, gy{k}] = gradient(im(:,:,k));
end
gx = sum(cat(3, gx{:}).^2, 3);
gy = sum(cat(3, gy{:}).^2, 3);
sc = [0 1; 1 0]*10;
vC = 1-exp(-gy/(2*sigma));
hC = 1-exp(-gx/(2*sigma));
data = cat(3, -log(p_in), -log(p_out));

figure(1)
subplot(1,2,1);
imagesc(log(p_in), [-5 5]), axis off, axis image
subplot(1,2,2);
imagesc(log(p_out), [-5 5]), axis off, axis image

gch = GraphCut('open', data, sc, vC+1, hC+1);
%gch = GraphCut('open', data, sc);
[gch labels] = GraphCut('swap', gch,10);

figure(2);
im1=im(:,:,1);im2=im(:,:,2);im3=im(:,:,3);
im1(labels==1)=0;im2(labels==1)=0;im3(labels==1)=1;
imshow( cat(3, im1, im2, im3));
keyboard;


% nC = sparse(H*W, H*W);
% for i0=1:(H-1)
%   for j0=1:(W-1)
%     i1 = i0; j1 = j0+1;
%     l0 = i0+(j0-1)*H;
%     l1 = i1+(j1-1)*H;
%     nC(l0, l1) = gx(i0, j0);
%     i1 = i0+1; j1 = j0;
%     l0 = i0+(j0-1)*H;
%     l1 = i1+(j1-1)*H;
%     nC(l0, l1) = gy(i0, j0);
%   end
% end
% h = GCO_Create(H*W, 2);
% GCO_SetDataCost(h,reshape(data, [H*W 2])');
% GCO_SetSmoothCost(h,[0 1; 1 0]*1e5);
% GCO_SetNeighbors(h,nC);
% GCO_Swap(h);
% l = GCO_GetLabeling(h);

